"""Train a small CNN on the real MNIST dataset (TensorFlow/Keras)."""
from pathlib import Path
import json
import numpy as np
import tensorflow as tf
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.linear_model import LogisticRegression

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
RESULTS_DIR = ROOT / "results"
MODEL_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# Reproducibility
SEED = 42
tf.keras.utils.set_random_seed(SEED)
np.random.seed(SEED)

def expected_calibration_error(probabilities, labels, bins=15):
    """Top-label expected calibration error (ECE)."""
    confidence = probabilities.max(axis=1)
    predictions = probabilities.argmax(axis=1)
    correct = (predictions == labels).astype(np.float64)
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for index in range(bins):
        mask = (confidence > edges[index]) & (confidence <= edges[index + 1])
        if np.any(mask):
            ece += mask.mean() * abs(correct[mask].mean() - confidence[mask].mean())
    return float(ece)

print("Downloading the real MNIST dataset from Keras...")
(x_train_all, y_train_all), (x_test_all, y_test_all) = tf.keras.datasets.mnist.load_data()

# Split the original 60,000 training images into 50,000 train + 10,000 validation.
x_train, y_train = x_train_all[:50000], y_train_all[:50000]
x_val, y_val = x_train_all[50000:], y_train_all[50000:]

# The assignment uses digits 1-9. Remove zero AFTER the split; keep test untouched except zero removal.
def prepare(x, y):
    keep = y != 0
    x = x[keep].astype("float32") / 255.0
    y = y[keep].astype("int64") - 1  # map original labels 1..9 to 0..8
    return x[..., None], y

x_train, y_train = prepare(x_train, y_train)
x_val, y_val = prepare(x_val, y_val)
x_test, y_test = prepare(x_test_all, y_test_all)

print(f"Training images (digits 1-9): {len(x_train):,}")
print(f"Validation images (digits 1-9): {len(x_val):,}")
print(f"Test images (digits 1-9): {len(x_test):,}")

model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(28, 28, 1)),
    tf.keras.layers.Conv2D(32, 3, activation="relu"),
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Conv2D(64, 3, activation="relu"),
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(96, activation="relu"),
    tf.keras.layers.Dropout(0.25),
    tf.keras.layers.Dense(9, activation="softmax"),
])
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
model.summary()

callbacks = [
    tf.keras.callbacks.EarlyStopping(monitor="val_accuracy", patience=2, restore_best_weights=True),
]
history = model.fit(
    x_train, y_train,
    validation_data=(x_val, y_val),
    epochs=6,
    batch_size=128,
    callbacks=callbacks,
    verbose=1,
)

loss, accuracy = model.evaluate(x_test, y_test, verbose=0)
probabilities = model.predict(x_test, batch_size=256, verbose=0)
predictions = probabilities.argmax(axis=1)
cm = confusion_matrix(y_test, predictions, labels=list(range(9)))
report = classification_report(y_test, predictions, labels=list(range(9)), output_dict=True, zero_division=0)
cnn_ece = expected_calibration_error(probabilities, y_test)

# Logistic Regression baseline. No multi_class argument: compatible with current scikit-learn.
print("Training Logistic Regression baseline...")
X_train_lr = x_train.reshape(len(x_train), -1)
X_test_lr = x_test.reshape(len(x_test), -1)
logistic = LogisticRegression(max_iter=300, solver="lbfgs", random_state=SEED)
logistic.fit(X_train_lr, y_train)
lr_probabilities = logistic.predict_proba(X_test_lr)
lr_predictions = logistic.predict(X_test_lr)
lr_accuracy = float(accuracy_score(y_test, lr_predictions))
lr_ece = expected_calibration_error(lr_probabilities, y_test)
lr_cm = confusion_matrix(y_test, lr_predictions, labels=list(range(9)))

model_path = MODEL_DIR / "mnist_digit_model.keras"
model.save(model_path)
np.savetxt(RESULTS_DIR / "confusion_matrix.csv", cm, delimiter=",", fmt="%d")
np.savetxt(RESULTS_DIR / "logistic_confusion_matrix.csv", lr_cm, delimiter=",", fmt="%d")
metrics = {
    "dataset": "MNIST (real images downloaded using tensorflow.keras.datasets.mnist)",
    "original_train_count": 60000,
    "original_test_count": 10000,
    "split_before_zero_filter": {"train": 50000, "validation": 10000},
    "digits_used": "1-9 (zero removed)",
    "train_images_after_zero_filter": int(len(x_train)),
    "validation_images_after_zero_filter": int(len(x_val)),
    "test_images_after_zero_filter": int(len(x_test)),
    "test_accuracy": float(accuracy),
    "test_loss": float(loss),
    "cnn_ece": cnn_ece,
    "logistic_regression": {
        "test_accuracy": lr_accuracy,
        "ece": lr_ece,
        "classification_report": classification_report(y_test, lr_predictions, labels=list(range(9)), output_dict=True, zero_division=0),
        "confusion_matrix_file": "results/logistic_confusion_matrix.csv"
    },
    "classification_report": report,
    "epochs_completed": len(history.history["loss"]),
    "model_file": "models/mnist_digit_model.keras",
}
with open(RESULTS_DIR / "training_metrics.json", "w", encoding="utf-8") as f:
    json.dump(metrics, f, indent=2)
print(f"\nCNN test accuracy: {accuracy:.4f} | ECE: {cnn_ece:.4f}")
print(f"Logistic Regression test accuracy: {lr_accuracy:.4f} | ECE: {lr_ece:.4f}")
print(f"Saved model to: {model_path}")
print(f"Saved metrics and confusion matrix in: {RESULTS_DIR}")
