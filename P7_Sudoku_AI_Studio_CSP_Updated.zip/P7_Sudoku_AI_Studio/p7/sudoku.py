"""Small, readable Sudoku helpers: conflicts and backtracking solver."""
from typing import List, Optional, Tuple


def find_conflicts(grid: List[int]) -> List[Tuple[int, int]]:
    conflicts = set()
    groups = []
    for r in range(9):
        groups.append([r * 9 + c for c in range(9)])
    for c in range(9):
        groups.append([r * 9 + c for r in range(9)])
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            groups.append([(br + dr) * 9 + bc + dc for dr in range(3) for dc in range(3)])
    for group in groups:
        seen = {}
        for cell in group:
            value = grid[cell]
            if value:
                if value in seen:
                    conflicts.add(tuple(sorted((seen[value], cell))))
                else:
                    seen[value] = cell
    return sorted(conflicts)


def valid_grid(grid: List[int]) -> bool:
    return len(grid) == 81 and all(0 <= x <= 9 for x in grid) and not find_conflicts(grid)


def _peers(cell: int) -> set[int]:
    """Return all cells sharing a row, column, or 3x3 box with cell."""
    r, c = divmod(cell, 9)
    peers = {r * 9 + j for j in range(9)}
    peers.update(i * 9 + c for i in range(9))
    br, bc = (r // 3) * 3, (c // 3) * 3
    peers.update((br + dr) * 9 + bc + dc for dr in range(3) for dc in range(3))
    peers.discard(cell)
    return peers


_PEER_MAP = [_peers(i) for i in range(81)]


def _initial_domains(board):
    domains = {}
    for cell, value in enumerate(board):
        if value:
            domains[cell] = {value}
        else:
            used = {board[p] for p in _PEER_MAP[cell] if board[p]}
            domains[cell] = set(range(1, 10)) - used
        if not domains[cell]:
            return None
    return domains


def _select_unassigned(domains, board):
    unassigned = [i for i, value in enumerate(board) if value == 0]
    return min(unassigned, key=lambda cell: (len(domains[cell]), cell)) if unassigned else None


def _solve_backtracking(board):
    """Plain MRV backtracking: try values and undo failed assignments."""
    domains = _initial_domains(board)
    if domains is None:
        return None

    def visit():
        cell = _select_unassigned(domains, board)
        if cell is None:
            return True
        for value in sorted(domains[cell]):
            if all(board[p] != value for p in _PEER_MAP[cell]):
                board[cell] = value
                if visit():
                    return True
                board[cell] = 0
        return False

    return board if visit() else None


def _solve_forward_checking(board):
    """Backtracking with forward checking of every unassigned peer domain."""
    domains = _initial_domains(board)
    if domains is None:
        return None

    def visit():
        cell = _select_unassigned(domains, board)
        if cell is None:
            return True
        for value in sorted(domains[cell]):
            if any(board[p] == value for p in _PEER_MAP[cell]):
                continue
            board[cell] = value
            changed = []
            failed = False
            for peer in _PEER_MAP[cell]:
                if board[peer] == 0 and value in domains[peer]:
                    old_domain = domains[peer]
                    new_domain = old_domain - {value}
                    domains[peer] = new_domain
                    changed.append((peer, old_domain))
                    if not new_domain:
                        failed = True
                        break
            if not failed and visit():
                return True
            board[cell] = 0
            for peer, old_domain in changed:
                domains[peer] = old_domain
        return False

    return board if visit() else None


def _ac3(domains):
    """Enforce arc consistency for binary Sudoku constraints (Xi != Xj)."""
    from collections import deque
    queue = deque((i, j) for i in range(81) for j in _PEER_MAP[i])
    while queue:
        xi, xj = queue.popleft()
        if len(domains[xj]) == 1:
            only = next(iter(domains[xj]))
            if only in domains[xi] and len(domains[xi]) > 1:
                domains[xi] = domains[xi] - {only}
                if not domains[xi]:
                    return False
                for xk in _PEER_MAP[xi] - {xj}:
                    queue.append((xk, xi))
    return True


def _solve_ac3(board):
    """AC-3 domain propagation combined with backtracking when needed."""
    domains = _initial_domains(board)
    if domains is None or not _ac3(domains):
        return None

    def visit():
        cell = _select_unassigned(domains, board)
        if cell is None:
            return True
        for value in sorted(domains[cell]):
            if any(board[p] == value for p in _PEER_MAP[cell]):
                continue
            board[cell] = value
            # Copy domains so a failed branch can be discarded safely.
            branch_domains = {k: set(v) for k, v in domains.items()}
            branch_domains[cell] = {value}
            consistent = True
            # Remove the assigned value from every peer, then enforce AC-3.
            for peer in _PEER_MAP[cell]:
                if board[peer] == 0 and value in branch_domains[peer]:
                    branch_domains[peer].discard(value)
                    if not branch_domains[peer]:
                        consistent = False
                        break
            if consistent and _ac3(branch_domains):
                old_domains = domains.copy()
                domains.clear()
                domains.update(branch_domains)
                if visit():
                    return True
                domains.clear()
                domains.update(old_domains)
            board[cell] = 0
        return False

    return board if visit() else None


def solve_sudoku(grid: List[int], method: str = "Backtracking") -> Optional[List[int]]:
    """Solve a Sudoku with Backtracking, Forward Checking, or AC-3 + search."""
    if not valid_grid(grid):
        return None
    board = grid[:]
    key = method.strip().lower().replace("-", "").replace("_", " ")
    if key in {"backtracking", "bt"}:
        return _solve_backtracking(board)
    if key in {"forward checking", "forwardchecking", "fc"}:
        return _solve_forward_checking(board)
    if key in {"ac 3", "ac3", "arc consistency"}:
        return _solve_ac3(board)
    raise ValueError("method must be Backtracking, Forward Checking, or AC-3")


def count_solutions(grid: List[int], limit: int = 2) -> int:
    if not valid_grid(grid):
        return 0
    board = grid[:]
    count = 0

    def candidates(cell):
        r, c = divmod(cell, 9)
        used = set(board[r * 9:(r + 1) * 9])
        used.update(board[rr * 9 + c] for rr in range(9))
        br, bc = (r // 3) * 3, (c // 3) * 3
        used.update(board[(br + dr) * 9 + bc + dc] for dr in range(3) for dc in range(3))
        return [d for d in range(1, 10) if d not in used]

    def visit():
        nonlocal count
        if count >= limit:
            return
        empty = [i for i, v in enumerate(board) if v == 0]
        if not empty:
            count += 1
            return
        cell, values = min(((i, candidates(i)) for i in empty), key=lambda item: len(item[1]))
        for value in values:
            board[cell] = value
            visit()
            board[cell] = 0
            if count >= limit:
                return
    visit()
    return count


def make_demo(seed: int = 7, givens: int = 36, mistakes: int = 2):
    """Create a reproducible Sudoku and inject visible wrong readings for method comparison."""
    import random
    rng = random.Random(seed)
    base = [((r * 3 + r // 3 + c) % 9) + 1 for r in range(9) for c in range(9)]
    # Shuffle symbols and rows/columns within bands/stacks to vary the board while preserving validity.
    symbols = list(range(1, 10))
    rng.shuffle(symbols)
    solution = [symbols[v - 1] for v in base]
    cells = list(range(81))
    rng.shuffle(cells)
    kept = set(cells[:givens])
    puzzle = [solution[i] if i in kept else 0 for i in range(81)]
    filled = [i for i, v in enumerate(puzzle) if v]
    rng.shuffle(filled)
    changed = []
    for cell in filled:
        if len(changed) >= mistakes:
            break
        correct = puzzle[cell]
        # Pick a different digit that creates a duplicate in at least one peer group.
        r, c = divmod(cell, 9)
        peers = set(puzzle[r * 9:(r + 1) * 9])
        peers.update(puzzle[rr * 9 + c] for rr in range(9))
        br, bc = (r // 3) * 3, (c // 3) * 3
        peers.update(puzzle[(br + dr) * 9 + bc + dc] for dr in range(3) for dc in range(3))
        options = [d for d in range(1, 10) if d != correct and d in peers]
        if options:
            wrong = rng.choice(options)
            puzzle[cell] = wrong
            changed.append((cell, wrong, correct))
    return puzzle, solution, changed
